//  Numerical Methods II, Spring 2012, Courant Institute

//  Jonathan Goodman, goodman@cims.nyu.edu, started February, 2012  (Enter your own data here)

//  C++ code for Assignment 3,

//  Source file testInterp.C, the main() that tests the interpolation routine



using namespace std;

#include <iostream>
#include "heat.h"


int main() {

  cout << "Hello from the interpolation tester" << endl;
  
  return 0;
 }