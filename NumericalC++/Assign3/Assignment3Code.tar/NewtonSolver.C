//  Numerical Methods II, Spring 2012, Courant Institute

//  Jonathan Goodman, goodman@cims.nyu.edu, started February, 2012  (Enter your own data here)

//  C++ code for Assignment 3,

//  Source file main.C, the main() for the main executable



using namespace std;

#include <iostream>
#include "heat.h"


int NewtonSolver( double u[], int nx, int ny);