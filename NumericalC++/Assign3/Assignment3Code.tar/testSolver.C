//  Numerical Methods II, Spring 2012, Courant Institute

//  Jonathan Goodman, goodman@cims.nyu.edu, started February, 2012  (Enter your own data here)

//  C++ code for Assignment 3,

//  Source file testSolver.C, the main() that tests the elliptic solver



using namespace std;

#include <iostream>
#include "heat.h"


int main() {

  cout << "Hello from the elliptic solver  tester" << endl;
  
  return 0;
 }